"""Adapter stub."""
